package com.azamseataxi.seaman;
import android.app.*;import android.content.*;import android.os.Build;import androidx.core.app.NotificationCompat;
public class OperationAlarmReceiver extends BroadcastReceiver{
 public static final String EXTRA_INDEX="alarmIndex"; private static final int BASE=61000;
 @Override public void onReceive(Context c,Intent in){int idx=in==null?-1:in.getIntExtra(EXTRA_INDEX,-1);long cutoff=in==null?0:in.getLongExtra(LocationForegroundService.EXTRA_CUTOFF,0);String lang=in==null?"sw":in.getStringExtra(LocationForegroundService.EXTRA_LANGUAGE);if(lang==null)lang="sw";
  if(idx==4|| (cutoff>0&&System.currentTimeMillis()>=cutoff)){c.stopService(new Intent(c,LocationForegroundService.class));notify(c,5,lang,lang.equals("en")?"Operation closed":"Operation imefungwa");return;}
  String[] sw={"Tahadhari: Operation itafungwa kiotomatiki baada ya dakika 30.","Tahadhari: Zimesalia dakika 15 kabla ya operation kufungwa kiotomatiki.","Tahadhari: Zimesalia dakika 5 kabla ya operation kufungwa kiotomatiki.","Tahadhari: Operation itafungwa kiotomatiki baada ya dakika 1."};
  String[] en={"Warning: Operation will auto-close in 30 minutes.","Warning: 15 minutes left before operation auto-closes.","Warning: 5 minutes left before operation auto-closes.","Warning: Operation will auto-close in 1 minute."}; if(idx>=0&&idx<4)notify(c,idx,lang,lang.equals("en")?en[idx]:sw[idx]);
 }
 private void notify(Context c,int idx,String lang,String body){String ch="seataxi_operation_warnings";NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(ch,"SEATAXI SEAMAN — Tahadhari",NotificationManager.IMPORTANCE_HIGH));PendingIntent p=PendingIntent.getActivity(c,0,c.getPackageManager().getLaunchIntentForPackage(c.getPackageName()),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification n=new NotificationCompat.Builder(c,ch).setSmallIcon(R.drawable.ic_stat_seataxi).setContentTitle("SEATAXI SEAMAN").setContentText(body).setAutoCancel(true).setContentIntent(p).setPriority(NotificationCompat.PRIORITY_HIGH).build();nm.notify(BASE+idx,n);}
}
