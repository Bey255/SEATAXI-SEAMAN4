# SEATAXI SEAMAN — Android project

Offline-first maritime operations app, Capacitor Android project.
Build the APK via the included GitHub Actions workflow (`.github/workflows/build-android.yml`) — no local Android SDK needed.

## This pass covers (not exhaustive — see gaps below)

- Native SQLite-backed trip-detection engine (new `android-native/TripDb.java`),
  moved out of JS-only execution into `LocationForegroundService` so trips are
  detected and durably persisted even while the WebView is suspended/killed.
  JS reconciles via `SeataxiLocation.getPersistedTrips()` on resume/visibility
  change and a live `tripPersisted` broadcast — exactly one authoritative
  engine (native), JS's own geofence logic now only runs as a non-native
  fallback.
- `FusedLocationProviderClient` (~750ms), monotonic elapsedRealtime ordering,
  `START_REDELIVER_INTENT`.
- Integer-only, truncated (not rounded) speedometer display.
- Global time display is HH:mm, no seconds (internal timestamps unchanged).
- THEME renamed, exactly Light Mode/Dark Mode/System (old 4th "redblue"
  option removed, migrated to Light for existing users).
- Bunkering is its own event type with fuel fields, not an emergency.
- Role-specific bottom nav: SKIPPER = Dashboard/Activity/Settings,
  OS = Dashboard/Wire/Settings. Activity = Reports + Trip History toggle.
- Boat Requirements removed from Skipper; OS dashboard has the 4 floating
  shortcuts (Badili Boti/Mahitaji ya Boti/Map/Imani).
- IMANI → Dua/Qibla chooser; Qibla is a new, honestly-labeled best-effort
  compass (GPS bearing + device compass), not a pre-existing feature.
- MAP is a new offline schematic (DAR/KIGAMBONI/vessel position plot) — this
  project has no bundled map tiles and must stay offline, so a real
  slippy map could not be built; this is a disclosed substitute, not the
  "existing map interface" the brief assumed exists.
- Reports: three-dot (⋯) menu with VIEW/EDIT/PDF/PHOTO/CSV/DELETE
  (PHOTO replaces "JPG" as the user-facing label).
- Preconfigured DAR/KIGAMBONI stations at the exact coordinates given,
  stored centrally; manual GPS calibration is now optional, not required.

## Known gaps (disclosed, not silently skipped)

- GPS status Part 2 refinements (distinguishing location-service-enabled vs
  permission vs tracking-session state as six separate signals) were only
  partially addressed — the existing gpsAvailable-based messaging was kept.
- Event/incident history list screen (Part 6) and Trip History individual
  delete (Part 7) were not added in this pass.
- Elevated floating bottom nav (Part 16) got CSS styling (rounded, shadow,
  inset) but not a full redesign pass.
- Part 5 (auto-closed report completion) was already fixed in an earlier
  pass via the `reportCompleted` flag; re-verified logic is intact, not
  re-tested end to end here.

## Verification status

No Android SDK/network in this environment — `npm install` / `cap sync` /
`gradlew assembleDebug` could not be run here. Every JS change was verified
with `node --check` plus duplicate-key/duplicate-function/missing-translation
scans (all clean). The native `TripDb`/`LocationForegroundService` changes
were hand-reviewed against the FusedLocationProviderClient and SQLiteOpenHelper
APIs but not compiled — this is the highest-risk unverified part of this
delivery. First real build verification is the GitHub Actions run.


## Offline map (Dar es Salaam port) — added

- The map is built **automatically during the GitHub Actions build** from
  OpenStreetMap data (Geofabrik Tanzania). You do not need a computer or the
  Garmin `.img` file.
- Engine: MapLibre GL, copied into `www/vendor/` at build time. Map data goes
  to `www/map/data/`. Everything is bundled in the APK — no internet at runtime.
- Shows: coastline/land, roads, piers & breakwaters, seamarks (buoys, lights,
  wrecks), ferry routes, place names, DAR/KIGAMBONI stations, your live
  position with distance + bearing to both terminals.
- Change the area: set `MAP_BBOX` (west,south,east,north) in the workflow step
  "Build offline map data", then change `map-data-v1` to `v2` in the cache key.
- If the map build fails, the app still builds and falls back to the old
  schematic map; the Actions log shows a warning.
- OSM seamarks are community data, NOT official charts. The map screen says so.
- Optional: put your own `*.osm.pbf` in `map-source/` to use it instead of the
  Geofabrik download.
- NOT tested on a real device/build yet (no network/SDK where this was written).
