#!/usr/bin/env bash
# Builds the offline map data for SEATAXI SEAMAN (runs inside GitHub Actions).
# Source: OpenStreetMap via Geofabrik (Tanzania). If you add your own .osm.pbf
# into the repo folder  map-source/  it is used instead of downloading.
set -euo pipefail

BBOX="${MAP_BBOX:-39.10,-7.00,39.55,-6.60}"            # west,south,east,north
CORE_BBOX="${MAP_CORE_BBOX:-39.25,-6.86,39.34,-6.78}"  # buildings only here
OUT="${MAP_OUT:-www/map/data}"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

echo "== Map area: $BBOX  (buildings in $CORE_BBOX)"

SRC=""
if compgen -G "map-source/*.osm.pbf" > /dev/null; then
  SRC="$(ls map-source/*.osm.pbf | head -n1)"
  echo "== Using local PBF: $SRC"
else
  echo "== Downloading Tanzania extract from Geofabrik"
  curl -fL --retry 5 --retry-delay 15 -o "$WORK/src.osm.pbf" \
    "https://download.geofabrik.de/africa/tanzania-latest.osm.pbf"
  SRC="$WORK/src.osm.pbf"
fi
ls -lh "$SRC"

echo "== Cutting the map area"
osmium extract -b "$BBOX" "$SRC" -o "$WORK/area.osm.pbf" --overwrite
osmium extract -b "$CORE_BBOX" "$WORK/area.osm.pbf" -o "$WORK/core.osm.pbf" --overwrite

exp() { # exp <input.pbf> <name> <geometry-types> <filters...>
  local in="$1" name="$2" geom="$3"; shift 3
  osmium tags-filter "$in" "$@" -o "$WORK/$name.pbf" --overwrite
  osmium export "$WORK/$name.pbf" -f geojson --geometry-types="$geom" \
    -o "$WORK/$name.geojson" --overwrite
}

echo "== Extracting layers"
exp "$WORK/area.osm.pbf" coast  linestring w/natural=coastline
exp "$WORK/area.osm.pbf" roads  linestring \
  w/highway=motorway,motorway_link,trunk,trunk_link,primary,primary_link,secondary,secondary_link,tertiary,tertiary_link,unclassified,residential,living_street
exp "$WORK/area.osm.pbf" water  polygon,linestring nwr/natural=water w/waterway=river,canal
exp "$WORK/core.osm.pbf" buildings polygon nwr/building
exp "$WORK/area.osm.pbf" places point n/place=city,town,suburb,quarter,village,hamlet,neighbourhood,island,islet,locality
exp "$WORK/area.osm.pbf" marine point,linestring,polygon \
  nwr/seamark:type nwr/man_made=pier,breakwater,groyne,quay,lighthouse \
  nwr/amenity=ferry_terminal nwr/route=ferry nwr/leisure=marina nwr/harbour \
  nwr/landuse=harbour nwr/waterway=dock nwr/natural=reef

echo "== Building app map files"
mkdir -p "$OUT"
python3 scripts/build-map-data.py "$WORK" "$OUT" "$BBOX"
echo "== Map data ready in $OUT"
