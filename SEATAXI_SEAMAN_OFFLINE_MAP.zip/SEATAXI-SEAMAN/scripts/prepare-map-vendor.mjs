// Copies the MapLibre GL library from node_modules into www/vendor so the
// app can load it with NO internet. Runs in CI after `npm install`.
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const src = path.join(root, 'node_modules', 'maplibre-gl', 'dist');
const dst = path.join(root, 'www', 'vendor');
if (!fs.existsSync(src)) {
  console.warn('::warning::maplibre-gl is not installed - the offline map will fall back to the schematic.');
  process.exit(0);
}
fs.mkdirSync(dst, { recursive: true });
for (const f of ['maplibre-gl.js', 'maplibre-gl.css']) {
  fs.copyFileSync(path.join(src, f), path.join(dst, f));
}
console.log('MapLibre copied to www/vendor');
